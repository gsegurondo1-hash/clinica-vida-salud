# Clínica Vida Salud · Aplicación web para gestionar citas médicas

Implementación del documento PUDS-UML (Sistemas 1). Cubre los 20 casos de uso de los dos ciclos.

```
clinica-vida-salud/
├── backend/                 API REST en PHP 8.2 + PostgreSQL (PDO)
│   ├── public/index.php     Punto de entrada y rutas (/api/...)
│   ├── app/core/            Env, Db, Http, V (validaciones), Auth (JWT), Router
│   ├── app/controllers/     Auth, Paciente, Usuario, Catalogo, Cita, Reporte
│   ├── app/services/        Mailer (correo) y Notificador (recordatorios)
│   ├── sql/                 esquema, datos de ejemplo, procedimientos y triggers
│   ├── scripts/             setup_db.php (crea la BD) y recordatorios.php (cron)
│   ├── docker/ + Dockerfile Imagen para Render
│   └── .env.example
├── frontend/                Sitio estático (HTML, CSS y JavaScript sin dependencias)
│   ├── index.html, css/, js/
│   └── build.sh             Genera js/config.js con la URL de la API (Render)
├── docker-compose.yml       Todo en local con un comando
└── render.yaml              Blueprint de Render (BD + API + sitio)
```

Las reglas de negocio críticas (sin citas duplicadas ni superpuestas, estados válidos, historial, bitácora, no borrar
registros con citas) viven en la base de datos: triggers y procedimientos del documento. La API solo los invoca.

## Cambios respecto a la versión anterior (alineación con el documento, Ciclo 2)

| Caso de uso | Qué se agregó |
|---|---|
| CU-20 Bitácora | Cada evento se muestra como una **frase legible** (por ejemplo «Cambió el estado de la cita CM-0006 de Programada a Cancelada») en vez de datos técnicos. Botón **Exportar CSV** (`GET /api/bitacora?formato=csv`, hasta 5000 eventos con los filtros activos). |
| CU-05 Usuarios y roles | Sección **Permisos por rol** (`GET/PUT /api/roles/{id}/permisos`). El rol Administrador siempre conserva `usuarios.gestionar`. El cambio queda en la bitácora. |
| Auditoría (CU-06, CU-07, CU-08, CU-17) | La bitácora ahora también registra altas, cambios y bajas de especialidades, horarios de atención y bloqueos de agenda (antes solo citas, pacientes, médicos y usuarios). |

No hay cambios en el esquema de la base de datos, por lo que no hace falta recrearla: basta con volver a desplegar.

## Cuentas iniciales

Las cuentas semilla (`admin`, `recepcion1`, `jperez`, `lfernandez`, `rjustiniano`, `mlopez`, `pgutierrez`, `asuarez`) se crean con la
contraseña de `DEMO_PASSWORD`; si no se define, se genera una aleatoria que aparece una sola vez en el registro del despliegue.
La pantalla de acceso **no muestra** cuentas ni contraseñas. En un sistema ya desplegado, cambie las contraseñas desde
*Usuarios y roles* (o desactive las cuentas que no use) para que nadie pueda entrar con las credenciales de ejemplo.

| Usuario | Rol |
|---|---|
| `admin` | Administrador |
| `recepcion1` | Recepcionista |
| `jperez`, `lfernandez`, `rjustiniano` | Médico |
| `mlopez`, `pgutierrez`, `asuarez` | Paciente |

## Ejecutar en local

### Opción A: Docker (la más simple)

```bash
docker compose up --build
```
Abra http://localhost:8080. La primera vez se crean las tablas y los datos de ejemplo.

### Opción B: sin Docker

Requisitos: PHP 8.1 o superior con las extensiones `pdo_pgsql` y `curl`, y PostgreSQL.
En XAMPP active `extension=pdo_pgsql` y `extension=pgsql` en `php.ini` y reinicie Apache.

```bash
# 1) Cree una base vacía
createdb -U postgres clinica_vida_salud

# 2) Backend
cd backend
cp .env.example .env            # ajuste DB_USER y DB_PASSWORD
php scripts/setup_db.php        # crea tablas, datos, procedimientos y triggers
php -S localhost:8000 -t public public/index.php

# 3) Frontend (otra terminal)
cd frontend
python -m http.server 8080      # o: npx serve -l 8080
```
Abra http://localhost:8080. Los módulos JavaScript necesitan un servidor HTTP: no abra `index.html` con doble clic.
Para recrear la base desde cero: `php scripts/setup_db.php --reset`.

## Desplegar en Render

### 0) Subir el proyecto a GitHub

```bash
git init && git add . && git commit -m "Clinica Vida Salud"
git branch -M main
git remote add origin https://github.com/SU_USUARIO/clinica-vida-salud.git
git push -u origin main
```

### Opción 1: Blueprint (automático)

1. En https://dashboard.render.com elija **New > Blueprint** y seleccione el repositorio. Render lee `render.yaml`.
2. Cuando lo pida, complete las variables marcadas sin valor:
   - `API_URL` = `https://clinica-vida-salud-api.onrender.com/api`
   - `CORS_ORIGIN` y `FRONTEND_URL` = `https://clinica-vida-salud-web.onrender.com`
   (si Render agrega un sufijo a los nombres, use las URLs reales de cada servicio).
3. Pulse **Apply**. Al terminar abra la URL del servicio `clinica-vida-salud-web`.

### Opción 2: Manual

1. **Base de datos**: New > PostgreSQL. Nombre `clinica-db`, plan Free. Copie la **Internal Database URL**.
2. **Backend**: New > Web Service > su repositorio.
   - Language: **Docker**. Root Directory: `backend`. Plan: Free.
   - Variables de entorno:

     | Variable | Valor |
     |---|---|
     | `DATABASE_URL` | Internal Database URL de la base |
     | `APP_SECRET` | texto aleatorio de 32 caracteres o más |
     | `APP_TIMEZONE` | `America/La_Paz` |
     | `DEMO_MODE` | `false` |
     | `CRON_SECRET` | texto aleatorio (para los recordatorios) |
     | `CORS_ORIGIN` | URL del frontend (se completa en el paso 4) |
     | `FRONTEND_URL` | URL del frontend (paso 4) |

   - Health Check Path: `/api/health`. Al primer arranque se crean las tablas y los datos de ejemplo.
   - Compruebe `https://SU-API.onrender.com/api/health`: debe responder `"base_de_datos": true`.
3. **Frontend**: New > Static Site > mismo repositorio.
   - Root Directory: `frontend`. Build Command: `sh build.sh`. Publish Directory: `.`
   - Variable: `API_URL` = `https://SU-API.onrender.com/api`
4. Vuelva al backend y complete `CORS_ORIGIN` y `FRONTEND_URL` con la URL del sitio estático (sin `/` final). Render reinicia el servicio.

### Recordatorios automáticos (CU-18)

Los cron jobs de Render son de pago. Opciones gratuitas: crear un trabajo diario en https://cron-job.org que llame a
`https://SU-API.onrender.com/api/cron/recordatorios` con la cabecera `X-Cron-Key: <valor de CRON_SECRET>`.
Genera los recordatorios de las citas de mañana y envía las notificaciones pendientes.

### Correos reales: recuperación de contraseña y notificaciones

El enlace para restablecer la contraseña **solo debe llegar al correo del usuario**. Por eso en la nube use
`DEMO_MODE=false`: así la pantalla nunca muestra el enlace. (`DEMO_MODE=true` sin proveedor de correo es solo para pruebas locales.)

Render gratis bloquea SMTP, de modo que el backend envía por API HTTPS con [Brevo](https://www.brevo.com) (plan gratis,
300 correos/día, no necesita dominio propio):

1. Cree una cuenta en Brevo y verifique su correo Gmail en **Senders, domains & dedicated IPs → Senders**.
2. En **SMTP & API → API keys** genere una clave.
3. En el backend de Render agregue: `BREVO_API_KEY` = la clave, `MAIL_FROM_EMAIL` = su Gmail verificado, `DEMO_MODE` = `false`.
4. Si Brevo muestra "transactional platform has not been activated", pida la activación a su soporte.

Los correos enviados desde una dirección Gmail pueden caer en spam; para uso real conviene un dominio propio.
Alternativa: Resend (`RESEND_API_KEY`), que sin dominio verificado solo envía al correo de su propia cuenta.
Sin ningún proveedor los correos se simulan y el paciente ve la notificación dentro de la aplicación.

### Límites del plan gratuito de Render

- El backend se duerme tras 15 minutos sin uso; la primera petición tarda cerca de un minuto en despertar.
- La base PostgreSQL gratuita **expira a los 30 días** de su creación (con unos días de gracia antes de borrarse) y no tiene
  copias de seguridad. Para una demostración sirve; para uso real conviene un plan de pago.
- La pantalla de acceso ya no muestra las cuentas de prueba (`MOSTRAR_DEMO=false` por defecto). Cambie las contraseñas de las cuentas semilla.

## API (resumen)

Autenticación con `Authorization: Bearer <token>`. Todas las rutas cuelgan de `/api`.

| Módulo | Rutas |
|---|---|
| Acceso | `POST /auth/login`, `/auth/registro`, `/auth/recuperar`, `/auth/restablecer`, `GET /auth/yo` |
| Perfil | `GET/PUT /perfil` |
| Usuarios | `GET/POST /usuarios`, `PUT /usuarios/{id}`, `GET /roles` |
| Catálogos | `/especialidades`, `/medicos`, `GET /medicos/{id}/horarios`, `/horarios`, `/bloqueos` |
| Pacientes | `GET/POST /pacientes`, `GET/PUT /pacientes/{id}`, `PATCH /pacientes/{id}/estado` |
| Citas | `GET /disponibilidad`, `GET/POST /citas`, `PUT /citas/{id}/reprogramar`, `POST /citas/{id}/cancelar`, `POST /citas/{id}/estado`, `GET /agenda`, `GET /historial` |
| Informes | `GET /reportes/{tipo}` (`&formato=csv`), `GET /bitacora`, `GET /notificaciones` |

## Seguridad del inicio de sesión

Tras 5 contraseñas incorrectas seguidas (`LOGIN_MAX_INTENTOS`) el acceso con ese usuario o correo se bloquea 15 minutos
(`LOGIN_BLOQUEO_MIN`). La pantalla avisa cuántos intentos quedan y muestra una cuenta regresiva durante el bloqueo.
El bloqueo se levanta antes si la persona restablece su contraseña por correo. Los intentos se guardan en la tabla
`intentos_login`, que se crea sola aunque la base ya esté desplegada.

## Notas sobre el documento

- El bloqueo por intentos fallidos no figura en el documento; se agregó como mejora de seguridad.
- El Administrador recibe `agenda.consultar` y la Recepcionista `reportes.ver`, porque CU-15 y CU-19 los listan como actores
  y la tabla de permisos de ejemplo no los incluía.
- La paciente PAC-0003 tiene correo `asuarez@mail.com` (igual que su cuenta) para poder recibir notificaciones.
- La exportación a PDF se resuelve con "Imprimir o guardar PDF" del navegador (mejora opcional del documento).
